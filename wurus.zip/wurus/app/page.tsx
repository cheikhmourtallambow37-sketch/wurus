import Link from "next/link";
import { Logo } from "@/components/ui";

const points = [
  {
    t: "Stock au poids",
    d: "Chaque pièce avec son poids, son titre d'or et son prix calculé automatiquement selon le prix du gramme du jour.",
  },
  {
    t: "Ventes à crédit",
    d: "Acompte, versements mensuels, retards repérés d'un coup d'œil et rappels WhatsApp prêts à envoyer.",
  },
  {
    t: "Reçus et commandes",
    d: "Un reçu propre à chaque paiement, et le suivi de chaque commande sur mesure jusqu'à la livraison.",
  },
];

export default function Accueil() {
  return (
    <div className="min-h-screen bg-white">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <Logo />
        <Link href="/connexion" className="btn-ghost btn-sm">
          Se connecter
        </Link>
      </header>

      <section className="mx-auto max-w-5xl px-5 pb-16 pt-10 sm:pt-20">
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-orange">Pour les bijoutiers</p>
        <h1 className="max-w-2xl text-4xl font-extrabold leading-tight text-nuit sm:text-5xl">
          Le cahier de ta bijouterie, enfin sur ton téléphone.
        </h1>
        <p className="mt-5 max-w-xl text-lg text-mute">
          Wurus garde ton stock, tes crédits clients et tes commandes en ordre, pour que plus aucun versement ne
          t&apos;échappe.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/connexion?mode=inscription" className="btn-primary">
            Essayer 30 jours gratuitement
          </Link>
          <Link href="/connexion" className="btn-ghost">
            J&apos;ai déjà un compte
          </Link>
        </div>
      </section>

      <section className="border-t border-line bg-nuit-100/40">
        <div className="mx-auto grid max-w-5xl gap-4 px-5 py-14 sm:grid-cols-3">
          {points.map((p) => (
            <div key={p.t} className="card">
              <div className="mb-3 h-1.5 w-10 rounded-full bg-orange" />
              <h2 className="text-lg font-bold text-nuit">{p.t}</h2>
              <p className="mt-2 text-sm text-mute">{p.d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto max-w-5xl px-5 py-8 text-sm text-mute">© Wurus — fait à Dakar</footer>
    </div>
  );
}
