"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { useBoutique } from "@/lib/boutique";
import { fcfa, whatsappLink } from "@/lib/format";
import { Badge, Empty, Field, Loading, Modal, PageHeader } from "@/components/ui";

const VIDE = { nom: "", telephone: "", adresse: "", notes: "" };

export default function Clients() {
  const { boutique } = useBoutique();
  const [clients, setClients] = useState<any[] | null>(null);
  const [ventes, setVentes] = useState<any[]>([]);
  const [paiements, setPaiements] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [form, setForm] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);

  const charger = useCallback(async () => {
    const [c, v, p] = await Promise.all([
      supabase.from("clients").select("*").eq("boutique_id", boutique.id).order("nom"),
      supabase.from("ventes").select("id, client_id, total, statut").eq("boutique_id", boutique.id),
      supabase.from("paiements").select("vente_id, montant").eq("boutique_id", boutique.id),
    ]);
    if (c.error) alert(c.error.message);
    setClients(c.data || []);
    setVentes(v.data || []);
    setPaiements(p.data || []);
  }, [boutique.id]);

  useEffect(() => {
    charger();
  }, [charger]);

  const resteParClient = useMemo(() => {
    const payeParVente: Record<string, number> = {};
    paiements.forEach((p) => (payeParVente[p.vente_id] = (payeParVente[p.vente_id] || 0) + Number(p.montant)));
    const m: Record<string, number> = {};
    ventes
      .filter((v) => v.statut === "en_cours" && v.client_id)
      .forEach((v) => {
        m[v.client_id] = (m[v.client_id] || 0) + Math.max(0, Number(v.total) - (payeParVente[v.id] || 0));
      });
    return m;
  }, [ventes, paiements]);

  const liste = useMemo(() => {
    const t = q.trim().toLowerCase();
    return (clients || []).filter((c) => !t || [c.nom, c.telephone].some((v) => String(v || "").toLowerCase().includes(t)));
  }, [clients, q]);

  async function enregistrer() {
    if (!form.nom.trim()) return alert("Le nom du client est obligatoire.");
    setBusy(true);
    const payload = {
      boutique_id: boutique.id,
      nom: form.nom.trim(),
      telephone: form.telephone || null,
      adresse: form.adresse || null,
      notes: form.notes || null,
    };
    const { error } = form.id
      ? await supabase.from("clients").update(payload).eq("id", form.id)
      : await supabase.from("clients").insert(payload);
    setBusy(false);
    if (error) return alert(error.message);
    setForm(null);
    charger();
  }

  async function supprimer() {
    if (!confirm("Supprimer ce client ? Ses ventes sont conservées.")) return;
    const { error } = await supabase.from("clients").delete().eq("id", form.id);
    if (error) return alert(error.message);
    setForm(null);
    charger();
  }

  if (!clients) return <Loading />;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Clients"
        subtitle="Tes clients et ce qu'ils te doivent."
        action={
          <button className="btn-primary" onClick={() => setForm({ ...VIDE })}>
            + Ajouter
          </button>
        }
      />
      <input className="input" placeholder="Rechercher un client…" value={q} onChange={(e) => setQ(e.target.value)} />

      {liste.length === 0 ? (
        <Empty>{clients.length === 0 ? "Aucun client pour l'instant." : "Aucun client ne correspond."}</Empty>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {liste.map((c) => {
            const reste = resteParClient[c.id] || 0;
            return (
              <div key={c.id} className="card">
                <div className="flex items-start justify-between gap-2">
                  <button className="text-left" onClick={() => setForm({ ...VIDE, ...c, telephone: c.telephone || "", adresse: c.adresse || "", notes: c.notes || "" })}>
                    <p className="font-semibold text-nuit">{c.nom}</p>
                    <p className="text-xs text-mute">{c.telephone || "Sans téléphone"}</p>
                  </button>
                  {reste > 0 ? <Badge tone="orange">Doit {fcfa(reste)}</Badge> : <Badge tone="gray">À jour</Badge>}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {c.telephone ? (
                    <>
                      <a className="btn-ghost btn-sm" href={`tel:${c.telephone}`}>
                        Appeler
                      </a>
                      <a className="btn-ghost btn-sm" href={whatsappLink(c.telephone, `Bonjour ${c.nom}, `)} target="_blank" rel="noreferrer">
                        WhatsApp
                      </a>
                    </>
                  ) : null}
                  <Link className="btn-ghost btn-sm" href={`/app/ventes/nouvelle?client=${c.id}`}>
                    Nouvelle vente
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? "Modifier le client" : "Nouveau client"}>
        {form ? (
          <div className="space-y-3">
            <Field label="Nom complet">
              <input className="input" value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} />
            </Field>
            <Field label="Téléphone / WhatsApp">
              <input className="input" inputMode="tel" value={form.telephone} onChange={(e) => setForm({ ...form, telephone: e.target.value })} placeholder="77 000 00 00" />
            </Field>
            <Field label="Adresse">
              <input className="input" value={form.adresse} onChange={(e) => setForm({ ...form, adresse: e.target.value })} />
            </Field>
            <Field label="Notes">
              <textarea className="input" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
            <div className="flex gap-2 pt-1">
              <button className="btn-primary flex-1" disabled={busy} onClick={enregistrer}>
                {busy ? "Enregistrement…" : "Enregistrer"}
              </button>
              {form.id ? (
                <button className="btn-danger" onClick={supprimer}>
                  Supprimer
                </button>
              ) : null}
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
