"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useBoutique } from "@/lib/boutique";
import { echeancesCouvertes, etatCredit } from "@/lib/credit";
import { MOYENS, dateFr, fcfa, numeroRecu, today, whatsappLink } from "@/lib/format";
import { messageRappel } from "@/lib/rappel";
import { Badge, Field, Loading, Stat } from "@/components/ui";

export default function DetailVente() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { boutique } = useBoutique();
  const [vente, setVente] = useState<any>(null);
  const [lignes, setLignes] = useState<any[]>([]);
  const [paiements, setPaiements] = useState<any[]>([]);
  const [montant, setMontant] = useState("");
  const [moyen, setMoyen] = useState("especes");
  const [date, setDate] = useState(today());
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const charger = useCallback(async () => {
    const [v, l, p] = await Promise.all([
      supabase.from("ventes").select("*, clients(nom, telephone)").eq("id", id).maybeSingle(),
      supabase.from("vente_lignes").select("*").eq("vente_id", id),
      supabase.from("paiements").select("*").eq("vente_id", id).order("created_at", { ascending: true }),
    ]);
    setVente(v.data || false);
    setLignes(l.data || []);
    setPaiements(p.data || []);
  }, [id]);

  useEffect(() => {
    charger();
  }, [charger]);

  if (vente === null) return <Loading />;
  if (vente === false)
    return (
      <div className="card text-center text-sm text-mute">
        Vente introuvable. <Link href="/app/ventes" className="font-semibold text-orange underline">Retour aux ventes</Link>
      </div>
    );

  const paye = paiements.reduce((s, p) => s + Number(p.montant), 0);
  const etat = etatCredit(vente, paye);
  const echeances = vente.mode === "credit" ? echeancesCouvertes(vente, paye) : [];
  const client = vente.clients;
  const actif = vente.statut === "en_cours";

  async function encaisser() {
    const m = Number(montant);
    if (!m || m <= 0) return alert("Saisis un montant.");
    if (m > etat.reste) return alert(`Le montant dépasse le reste à payer (${fcfa(etat.reste)}).`);
    setBusy(true);
    const { data, error } = await supabase
      .from("paiements")
      .insert({
        boutique_id: boutique.id,
        vente_id: vente.id,
        date_paiement: date,
        montant: m,
        moyen,
        note: note || null,
        numero_recu: numeroRecu(),
      })
      .select()
      .single();
    if (error) {
      setBusy(false);
      return alert(error.message);
    }
    if (paye + m >= Number(vente.total)) {
      await supabase.from("ventes").update({ statut: "solde" }).eq("id", vente.id);
    }
    router.push(`/app/recu/${data.id}`);
  }

  async function annuler() {
    if (!confirm("Annuler cette vente ? Les pièces retournent en stock. Les remboursements éventuels restent à gérer toi-même.")) return;
    const ids = lignes.map((l) => l.produit_id).filter(Boolean);
    const { error } = await supabase.from("ventes").update({ statut: "annule" }).eq("id", vente.id);
    if (error) return alert(error.message);
    if (ids.length) await supabase.from("produits").update({ statut: "en_stock" }).in("id", ids);
    charger();
  }

  const rappel = client?.telephone
    ? whatsappLink(
        client.telephone,
        messageRappel({
          client: client.nom,
          boutique: boutique.nom,
          dateVente: vente.date_vente,
          reste: etat.reste,
          retard: etat.retard,
          prochaine: etat.prochaine,
        })
      )
    : null;

  return (
    <div className="space-y-5">
      <div>
        <Link href="/app/ventes" className="text-sm text-mute hover:text-nuit">
          ← Ventes
        </Link>
        <div className="mt-2 flex items-start justify-between gap-3">
          <div>
            <h1 className="h1">{client?.nom || "Client de passage"}</h1>
            <p className="text-sm text-mute">
              Vente du {dateFr(vente.date_vente)} · {vente.mode === "credit" ? "À crédit" : "Comptant"}
            </p>
          </div>
          {vente.statut === "annule" ? (
            <Badge tone="gray">Annulée</Badge>
          ) : vente.statut === "solde" ? (
            <Badge tone="green">Soldée</Badge>
          ) : etat.enRetard ? (
            <Badge tone="red">En retard</Badge>
          ) : (
            <Badge tone="orange">En cours</Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Stat label="Total" value={fcfa(vente.total)} />
        <Stat label="Déjà payé" value={fcfa(paye)} tone="nuit" />
        <Stat label="Reste" value={fcfa(etat.reste)} tone={etat.enRetard ? "red" : "orange"} />
      </div>

      {etat.enRetard ? (
        <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-600">Retard de paiement : {fcfa(etat.retard)} auraient dû être réglés à ce jour.</p>
      ) : null}

      {actif && rappel ? (
        <a className="btn-dark w-full" href={rappel} target="_blank" rel="noreferrer">
          Envoyer un rappel WhatsApp
        </a>
      ) : null}

      <section className="card">
        <h2 className="mb-2 font-bold text-nuit">Pièces</h2>
        <div className="divide-y divide-line">
          {lignes.map((l) => (
            <div key={l.id} className="flex justify-between py-2 text-sm">
              <span className="text-ink">{l.designation}</span>
              <span className="font-semibold text-nuit">{fcfa(l.prix)}</span>
            </div>
          ))}
        </div>
      </section>

      {echeances.length > 0 ? (
        <section className="card">
          <h2 className="mb-2 font-bold text-nuit">Échéancier</h2>
          <div className="divide-y divide-line">
            {echeances.map((e) => (
              <div key={e.n} className="flex items-center justify-between py-2 text-sm">
                <span>
                  Versement {e.n} · {dateFr(e.date)}
                </span>
                <span className="flex items-center gap-2">
                  <strong className="text-nuit">{fcfa(e.montant)}</strong>
                  {e.payee ? <Badge tone="green">Payé</Badge> : e.date < today() ? <Badge tone="red">En retard</Badge> : <Badge tone="gray">À venir</Badge>}
                </span>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="card">
        <h2 className="mb-2 font-bold text-nuit">Paiements reçus</h2>
        {paiements.length === 0 ? (
          <p className="text-sm text-mute">Aucun paiement enregistré.</p>
        ) : (
          <div className="divide-y divide-line">
            {paiements.map((p) => (
              <div key={p.id} className="flex items-center justify-between py-2 text-sm">
                <span>
                  {dateFr(p.date_paiement)} · {MOYENS[p.moyen]}
                  {p.note ? <span className="text-mute"> · {p.note}</span> : null}
                </span>
                <span className="flex items-center gap-3">
                  <strong className="text-nuit">{fcfa(p.montant)}</strong>
                  <Link href={`/app/recu/${p.id}`} className="font-semibold text-orange underline">
                    Reçu
                  </Link>
                </span>
              </div>
            ))}
          </div>
        )}
      </section>

      {actif && etat.reste > 0 ? (
        <section className="card space-y-3">
          <h2 className="font-bold text-nuit">Encaisser un versement</h2>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Montant (FCFA)">
              <input
                className="input"
                inputMode="numeric"
                value={montant}
                onChange={(e) => setMontant(e.target.value)}
                placeholder={String(etat.retard > 0 ? etat.retard : etat.prochaine?.montant || etat.reste)}
              />
            </Field>
            <Field label="Moyen">
              <select className="input" value={moyen} onChange={(e) => setMoyen(e.target.value)}>
                {Object.entries(MOYENS).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Date">
              <input className="input" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
            <Field label="Note (optionnel)">
              <input className="input" value={note} onChange={(e) => setNote(e.target.value)} />
            </Field>
          </div>
          <div className="flex gap-2">
            <button className="btn-primary flex-1" disabled={busy} onClick={encaisser}>
              {busy ? "Enregistrement…" : "Enregistrer et voir le reçu"}
            </button>
            <button className="btn-ghost" onClick={() => setMontant(String(etat.reste))}>
              Tout solder
            </button>
          </div>
        </section>
      ) : null}

      {vente.statut !== "annule" ? (
        <button className="btn-danger w-full" onClick={annuler}>
          Annuler la vente
        </button>
      ) : null}
    </div>
  );
}
