"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { useBoutique } from "@/lib/boutique";
import { etatCredit } from "@/lib/credit";
import { dateFr, fcfa } from "@/lib/format";
import { Badge, Empty, Loading, PageHeader } from "@/components/ui";

const FILTRES = [
  { id: "tous", label: "Toutes" },
  { id: "credit", label: "À crédit" },
  { id: "retard", label: "En retard" },
  { id: "solde", label: "Soldées" },
];

export default function Ventes() {
  const { boutique } = useBoutique();
  const [ventes, setVentes] = useState<any[] | null>(null);
  const [paiements, setPaiements] = useState<any[]>([]);
  const [filtre, setFiltre] = useState("tous");

  useEffect(() => {
    (async () => {
      const [v, p] = await Promise.all([
        supabase
          .from("ventes")
          .select("*, clients(nom, telephone)")
          .eq("boutique_id", boutique.id)
          .order("date_vente", { ascending: false })
          .order("created_at", { ascending: false }),
        supabase.from("paiements").select("vente_id, montant").eq("boutique_id", boutique.id),
      ]);
      if (v.error) alert(v.error.message);
      setVentes(v.data || []);
      setPaiements(p.data || []);
    })();
  }, [boutique.id]);

  const lignes = useMemo(() => {
    const paye: Record<string, number> = {};
    paiements.forEach((p) => (paye[p.vente_id] = (paye[p.vente_id] || 0) + Number(p.montant)));
    return (ventes || []).map((v) => ({ v, etat: etatCredit(v, paye[v.id] || 0) }));
  }, [ventes, paiements]);

  const filtrees = lignes.filter(({ v, etat }) => {
    if (filtre === "credit") return v.mode === "credit" && v.statut === "en_cours";
    if (filtre === "retard") return etat.enRetard;
    if (filtre === "solde") return v.statut === "solde";
    return true;
  });

  if (!ventes) return <Loading />;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Ventes"
        subtitle="Comptant et à crédit, avec le suivi des versements."
        action={
          <Link href="/app/ventes/nouvelle" className="btn-primary">
            + Nouvelle vente
          </Link>
        }
      />

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTRES.map((f) => (
          <button
            key={f.id}
            onClick={() => setFiltre(f.id)}
            className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-medium ${filtre === f.id ? "bg-nuit text-white" : "bg-nuit-100 text-nuit"}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filtrees.length === 0 ? (
        <Empty>{ventes.length === 0 ? "Aucune vente pour l'instant. Enregistre la première avec le bouton ci-dessus." : "Aucune vente dans cette catégorie."}</Empty>
      ) : (
        <div className="space-y-3">
          {filtrees.map(({ v, etat }) => (
            <Link key={v.id} href={`/app/ventes/${v.id}`} className="card block transition hover:border-orange">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-nuit">{v.clients?.nom || "Client de passage"}</p>
                  <p className="text-xs text-mute">
                    {dateFr(v.date_vente)} · {v.mode === "credit" ? `Crédit ${v.nb_versements} versement${v.nb_versements > 1 ? "s" : ""}` : "Comptant"}
                  </p>
                </div>
                {v.statut === "annule" ? (
                  <Badge tone="gray">Annulée</Badge>
                ) : v.statut === "solde" ? (
                  <Badge tone="green">Soldée</Badge>
                ) : etat.enRetard ? (
                  <Badge tone="red">En retard</Badge>
                ) : (
                  <Badge tone="orange">En cours</Badge>
                )}
              </div>
              <div className="mt-3 flex items-end justify-between text-sm">
                <span className="text-mute">Total {fcfa(v.total)}</span>
                {v.statut === "en_cours" ? <span className="font-bold text-nuit">Reste {fcfa(etat.reste)}</span> : null}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
