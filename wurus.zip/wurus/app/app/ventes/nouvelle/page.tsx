"use client";
import { Suspense, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { prixProduit, useBoutique } from "@/lib/boutique";
import { MOYENS, addMonths, dateFr, fcfa, grammes, numeroRecu, today } from "@/lib/format";
import { echeancier } from "@/lib/credit";
import { Empty, Field, Loading, PageHeader } from "@/components/ui";

type Ligne = { produit: any; prix: string };

function Formulaire() {
  const router = useRouter();
  const params = useSearchParams();
  const { boutique, prix } = useBoutique();
  const [clients, setClients] = useState<any[] | null>(null);
  const [produits, setProduits] = useState<any[]>([]);
  const [clientId, setClientId] = useState(params.get("client") || "");
  const [nouveauClient, setNouveauClient] = useState(false);
  const [nc, setNc] = useState({ nom: "", telephone: "" });
  const [panier, setPanier] = useState<Ligne[]>([]);
  const [q, setQ] = useState("");
  const [mode, setMode] = useState<"comptant" | "credit">("comptant");
  const [acompte, setAcompte] = useState("");
  const [nb, setNb] = useState("3");
  const [moyen, setMoyen] = useState("especes");
  const [dateVente, setDateVente] = useState(today());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const [c, p] = await Promise.all([
        supabase.from("clients").select("id, nom, telephone").eq("boutique_id", boutique.id).order("nom"),
        supabase.from("produits").select("*").eq("boutique_id", boutique.id).eq("statut", "en_stock").order("created_at", { ascending: false }),
      ]);
      setClients(c.data || []);
      setProduits(p.data || []);
    })();
  }, [boutique.id]);

  const total = panier.reduce((s, l) => s + Number(l.prix || 0), 0);
  const acompteNum = Number(acompte || 0);
  const nbNum = Math.max(1, Math.min(24, Number(nb || 1)));
  const apercu = useMemo(
    () => (mode === "credit" ? echeancier({ total, acompte: acompteNum, nb_versements: nbNum, date_vente: dateVente }) : []),
    [mode, total, acompteNum, nbNum, dateVente]
  );

  const disponibles = produits.filter((p) => !panier.some((l) => l.produit.id === p.id)).filter((p) => {
    const t = q.trim().toLowerCase();
    return !t || [p.nom, p.reference, p.titre, p.categorie].some((v) => String(v || "").toLowerCase().includes(t));
  });

  function ajouter(p: any) {
    setPanier([...panier, { produit: p, prix: String(prixProduit(p, prix)) }]);
  }

  async function valider() {
    if (panier.length === 0) return alert("Ajoute au moins une pièce à la vente.");
    if (total <= 0) return alert("Le total de la vente est à zéro : vérifie les prix des pièces.");
    if (mode === "credit") {
      if (!clientId && !(nouveauClient && nc.nom.trim())) return alert("Une vente à crédit nécessite un client.");
      if (acompteNum >= total) return alert("L'acompte doit être inférieur au total (sinon choisis « Comptant »).");
      if (acompteNum < 0) return alert("Acompte invalide.");
    }
    setBusy(true);
    try {
      let cid: string | null = clientId || null;
      if (nouveauClient && nc.nom.trim()) {
        const { data, error } = await supabase
          .from("clients")
          .insert({ boutique_id: boutique.id, nom: nc.nom.trim(), telephone: nc.telephone || null })
          .select()
          .single();
        if (error) throw error;
        cid = data.id;
      }

      const paiementInitial = mode === "comptant" ? total : acompteNum;
      const { data: vente, error: ev } = await supabase
        .from("ventes")
        .insert({
          boutique_id: boutique.id,
          client_id: cid,
          date_vente: dateVente,
          total,
          mode,
          acompte: paiementInitial,
          nb_versements: mode === "credit" ? nbNum : null,
          echeance_finale: mode === "credit" ? addMonths(dateVente, nbNum) : null,
          statut: mode === "comptant" ? "solde" : "en_cours",
        })
        .select()
        .single();
      if (ev) throw ev;

      const { error: el } = await supabase.from("vente_lignes").insert(
        panier.map((l) => ({
          boutique_id: boutique.id,
          vente_id: vente.id,
          produit_id: l.produit.id,
          designation: [l.produit.nom, l.produit.titre, l.produit.poids_g ? grammes(l.produit.poids_g) : ""].filter(Boolean).join(" · "),
          prix: Number(l.prix || 0),
        }))
      );
      if (el) throw el;

      const { error: ep } = await supabase
        .from("produits")
        .update({ statut: "vendu" })
        .in("id", panier.map((l) => l.produit.id));
      if (ep) throw ep;

      if (paiementInitial > 0) {
        const { error: epay } = await supabase.from("paiements").insert({
          boutique_id: boutique.id,
          vente_id: vente.id,
          date_paiement: dateVente,
          montant: paiementInitial,
          moyen,
          numero_recu: numeroRecu(),
          note: mode === "credit" ? "Acompte" : "Paiement comptant",
        });
        if (epay) throw epay;
      }
      router.push(`/app/ventes/${vente.id}`);
    } catch (e: any) {
      setBusy(false);
      alert(e?.message || "Impossible d'enregistrer la vente.");
    }
  }

  if (!clients) return <Loading />;

  return (
    <div className="space-y-5 pb-4">
      <PageHeader title="Nouvelle vente" subtitle="Choisis les pièces, puis le mode de paiement." />

      <section className="card space-y-3">
        <h2 className="font-bold text-nuit">1. Pièces vendues</h2>
        {panier.length > 0 ? (
          <div className="space-y-2">
            {panier.map((l, i) => (
              <div key={l.produit.id} className="flex items-center gap-2 rounded-xl bg-nuit-100/60 p-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-nuit">{l.produit.nom}</p>
                  <p className="text-xs text-mute">
                    {l.produit.titre || "—"} · {grammes(l.produit.poids_g)}
                  </p>
                </div>
                <input
                  className="input w-28 text-right"
                  inputMode="numeric"
                  value={l.prix}
                  onChange={(e) => setPanier(panier.map((x, j) => (j === i ? { ...x, prix: e.target.value } : x)))}
                />
                <button className="btn-danger btn-sm" onClick={() => setPanier(panier.filter((_, j) => j !== i))} aria-label="Retirer">
                  ✕
                </button>
              </div>
            ))}
          </div>
        ) : null}
        <input className="input" placeholder="Rechercher une pièce en stock…" value={q} onChange={(e) => setQ(e.target.value)} />
        {produits.length === 0 ? (
          <Empty>Aucune pièce en stock. Ajoute d&apos;abord tes pièces dans l&apos;onglet Stock.</Empty>
        ) : (
          <div className="max-h-64 space-y-1.5 overflow-y-auto">
            {disponibles.slice(0, 30).map((p) => (
              <button key={p.id} onClick={() => ajouter(p)} className="flex w-full items-center justify-between rounded-xl border border-line px-3 py-2 text-left hover:border-orange">
                <span>
                  <span className="block text-sm font-medium text-nuit">{p.nom}</span>
                  <span className="text-xs text-mute">
                    {p.reference || "—"} · {p.titre || "—"} · {grammes(p.poids_g)}
                  </span>
                </span>
                <span className="text-sm font-bold text-nuit">{fcfa(prixProduit(p, prix))}</span>
              </button>
            ))}
          </div>
        )}
      </section>

      <section className="card space-y-3">
        <h2 className="font-bold text-nuit">2. Client</h2>
        {!nouveauClient ? (
          <>
            <select className="input" value={clientId} onChange={(e) => setClientId(e.target.value)}>
              <option value="">Client de passage (sans fiche)</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nom} {c.telephone ? `· ${c.telephone}` : ""}
                </option>
              ))}
            </select>
            <button className="text-sm font-semibold text-orange" onClick={() => { setNouveauClient(true); setClientId(""); }}>
              + Nouveau client
            </button>
          </>
        ) : (
          <>
            <Field label="Nom du client">
              <input className="input" value={nc.nom} onChange={(e) => setNc({ ...nc, nom: e.target.value })} />
            </Field>
            <Field label="Téléphone / WhatsApp">
              <input className="input" inputMode="tel" value={nc.telephone} onChange={(e) => setNc({ ...nc, telephone: e.target.value })} />
            </Field>
            <button className="text-sm font-semibold text-mute" onClick={() => setNouveauClient(false)}>
              Choisir un client existant
            </button>
          </>
        )}
      </section>

      <section className="card space-y-3">
        <h2 className="font-bold text-nuit">3. Paiement</h2>
        <div className="grid grid-cols-2 gap-2">
          {(["comptant", "credit"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`rounded-xl border px-3 py-2.5 text-sm font-semibold ${mode === m ? "border-nuit bg-nuit text-white" : "border-line text-nuit"}`}
            >
              {m === "comptant" ? "Comptant" : "À crédit"}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date de la vente">
            <input className="input" type="date" value={dateVente} onChange={(e) => setDateVente(e.target.value)} />
          </Field>
          <Field label="Moyen de paiement">
            <select className="input" value={moyen} onChange={(e) => setMoyen(e.target.value)}>
              {Object.entries(MOYENS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          {mode === "credit" ? (
            <>
              <Field label="Acompte versé (FCFA)">
                <input className="input" inputMode="numeric" value={acompte} onChange={(e) => setAcompte(e.target.value)} placeholder="0" />
              </Field>
              <Field label="Nombre de versements">
                <input className="input" inputMode="numeric" value={nb} onChange={(e) => setNb(e.target.value)} />
              </Field>
            </>
          ) : null}
        </div>
        {mode === "credit" && total > 0 && acompteNum < total ? (
          <div className="rounded-xl bg-nuit-100/60 p-3 text-sm text-nuit">
            <p className="mb-1 font-semibold">Échéancier prévu</p>
            {apercu.map((e) => (
              <p key={e.n} className="flex justify-between">
                <span>
                  Versement {e.n} · {dateFr(e.date)}
                </span>
                <strong>{fcfa(e.montant)}</strong>
              </p>
            ))}
          </div>
        ) : null}
      </section>

      <div className="sticky bottom-20 z-20 rounded-2xl border border-line bg-white p-3 shadow-lg sm:bottom-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm text-mute">Total de la vente</span>
          <span className="text-lg font-extrabold text-nuit">{fcfa(total)}</span>
        </div>
        <button className="btn-primary w-full" disabled={busy} onClick={valider}>
          {busy ? "Enregistrement…" : "Valider la vente"}
        </button>
      </div>
    </div>
  );
}

export default function NouvelleVente() {
  return (
    <Suspense fallback={<Loading />}>
      <Formulaire />
    </Suspense>
  );
}
