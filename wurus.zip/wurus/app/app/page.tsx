"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { prixProduit, useBoutique } from "@/lib/boutique";
import { etatCredit } from "@/lib/credit";
import { dateFr, fcfa, grammes, today, whatsappLink } from "@/lib/format";
import { messageRappel } from "@/lib/rappel";
import { Badge, Loading, Stat } from "@/components/ui";

export default function Accueil() {
  const { boutique, prix } = useBoutique();
  const [d, setD] = useState<any>(null);

  useEffect(() => {
    (async () => {
      const [p, v, pa, c] = await Promise.all([
        supabase.from("produits").select("*").eq("boutique_id", boutique.id).eq("statut", "en_stock"),
        supabase.from("ventes").select("*, clients(nom, telephone)").eq("boutique_id", boutique.id).eq("statut", "en_cours"),
        supabase.from("paiements").select("vente_id, montant").eq("boutique_id", boutique.id),
        supabase.from("commandes").select("*, clients(nom)").eq("boutique_id", boutique.id).neq("statut", "livre"),
      ]);
      setD({ produits: p.data || [], ventes: v.data || [], paiements: pa.data || [], commandes: c.data || [] });
    })();
  }, [boutique.id]);

  const calc = useMemo(() => {
    if (!d) return null;
    const paye: Record<string, number> = {};
    d.paiements.forEach((p: any) => (paye[p.vente_id] = (paye[p.vente_id] || 0) + Number(p.montant)));
    const credits = d.ventes.map((v: any) => ({ v, etat: etatCredit(v, paye[v.id] || 0) }));
    const t = today();
    return {
      nbStock: d.produits.length,
      poidsStock: d.produits.reduce((s: number, p: any) => s + Number(p.poids_g || 0), 0),
      valeurStock: d.produits.reduce((s: number, p: any) => s + prixProduit(p, prix), 0),
      aEncaisser: credits.reduce((s: number, x: any) => s + x.etat.reste, 0),
      enRetard: credits.filter((x: any) => x.etat.enRetard).sort((a: any, b: any) => b.etat.retard - a.etat.retard),
      commandesRetard: d.commandes.filter((c: any) => c.date_livraison && c.date_livraison < t),
      commandesPretes: d.commandes.filter((c: any) => c.statut === "pret"),
    };
  }, [d, prix]);

  if (!d || !calc) return <Loading />;

  const totalRetard = calc.enRetard.reduce((s: number, x: any) => s + x.etat.retard, 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="h1">Bonjour 👋</h1>
        <p className="text-sm text-mute">Voici l&apos;état de {boutique.nom} aujourd&apos;hui.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Pièces en stock" value={calc.nbStock} />
        <Stat label="Valeur du stock" value={fcfa(calc.valeurStock)} />
        <Stat label="Crédits à encaisser" value={fcfa(calc.aEncaisser)} tone="orange" />
        <Stat label="En retard" value={fcfa(totalRetard)} tone={totalRetard > 0 ? "red" : "nuit"} />
      </div>
      <p className="-mt-3 text-xs text-mute">Poids total en stock : {grammes(calc.poidsStock)}</p>

      <div className="grid grid-cols-3 gap-2 sm:max-w-md">
        <Link href="/app/ventes/nouvelle" className="btn-primary">
          Vente
        </Link>
        <Link href="/app/stock" className="btn-ghost">
          Stock
        </Link>
        <Link href="/app/commandes" className="btn-ghost">
          Commande
        </Link>
      </div>

      <section className="space-y-3">
        <h2 className="font-bold text-nuit">Paiements en retard</h2>
        {calc.enRetard.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line p-5 text-center text-sm text-mute">Aucun retard. Tout est à jour.</div>
        ) : (
          calc.enRetard.map(({ v, etat }: any) => (
            <div key={v.id} className="card flex items-center justify-between gap-3">
              <Link href={`/app/ventes/${v.id}`} className="min-w-0">
                <p className="truncate font-semibold text-nuit">{v.clients?.nom || "Client de passage"}</p>
                <p className="text-xs text-mute">
                  Vente du {dateFr(v.date_vente)} · reste {fcfa(etat.reste)}
                </p>
              </Link>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                <Badge tone="red">{fcfa(etat.retard)} en retard</Badge>
                {v.clients?.telephone ? (
                  <a
                    className="text-xs font-semibold text-orange underline"
                    target="_blank"
                    rel="noreferrer"
                    href={whatsappLink(
                      v.clients.telephone,
                      messageRappel({ client: v.clients.nom, boutique: boutique.nom, dateVente: v.date_vente, reste: etat.reste, retard: etat.retard, prochaine: etat.prochaine })
                    )}
                  >
                    Rappeler sur WhatsApp
                  </a>
                ) : null}
              </div>
            </div>
          ))
        )}
      </section>

      {calc.commandesPretes.length > 0 || calc.commandesRetard.length > 0 ? (
        <section className="space-y-3">
          <h2 className="font-bold text-nuit">Commandes à suivre</h2>
          {calc.commandesPretes.map((c: any) => (
            <Link key={c.id} href="/app/commandes" className="card flex items-center justify-between gap-3">
              <span className="truncate text-sm text-nuit">
                {c.description} <span className="text-mute">· {c.clients?.nom || "Sans client"}</span>
              </span>
              <Badge tone="green">Prête à remettre</Badge>
            </Link>
          ))}
          {calc.commandesRetard
            .filter((c: any) => c.statut !== "pret")
            .map((c: any) => (
              <Link key={c.id} href="/app/commandes" className="card flex items-center justify-between gap-3">
                <span className="truncate text-sm text-nuit">
                  {c.description} <span className="text-mute">· {c.clients?.nom || "Sans client"}</span>
                </span>
                <Badge tone="red">Livraison dépassée ({dateFr(c.date_livraison)})</Badge>
              </Link>
            ))}
        </section>
      ) : null}
    </div>
  );
}
