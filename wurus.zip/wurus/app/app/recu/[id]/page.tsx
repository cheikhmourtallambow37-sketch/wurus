"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useBoutique } from "@/lib/boutique";
import { MOYENS, dateFr, fcfa, whatsappLink } from "@/lib/format";
import { Loading } from "@/components/ui";

export default function Recu() {
  const { id } = useParams<{ id: string }>();
  const { boutique } = useBoutique();
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    (async () => {
      const { data: p } = await supabase.from("paiements").select("*").eq("id", id).maybeSingle();
      if (!p) return setData(false);
      const [v, l, tous] = await Promise.all([
        supabase.from("ventes").select("*, clients(nom, telephone)").eq("id", p.vente_id).maybeSingle(),
        supabase.from("vente_lignes").select("*").eq("vente_id", p.vente_id),
        supabase.from("paiements").select("id, montant, created_at").eq("vente_id", p.vente_id).order("created_at", { ascending: true }),
      ]);
      let cumul = 0;
      for (const x of tous.data || []) {
        cumul += Number(x.montant);
        if (x.id === p.id) break;
      }
      setData({ p, vente: v.data, lignes: l.data || [], cumul });
    })();
  }, [id]);

  if (data === null) return <Loading />;
  if (data === false) return <div className="card text-sm text-mute">Reçu introuvable.</div>;

  const { p, vente, lignes, cumul } = data;
  const reste = Math.max(0, Number(vente.total) - cumul);
  const client = vente.clients;
  const resume =
    `Reçu ${p.numero_recu || ""} — ${boutique.nom}\n` +
    `Date : ${dateFr(p.date_paiement)}\n` +
    `Montant reçu : ${fcfa(p.montant)} (${MOYENS[p.moyen]})\n` +
    `Total de l'achat : ${fcfa(vente.total)}\n` +
    `Déjà payé : ${fcfa(cumul)}\n` +
    (reste > 0 ? `Reste à payer : ${fcfa(reste)}\n` : "Achat soldé. Merci de votre confiance !\n");

  return (
    <div className="mx-auto max-w-md space-y-4">
      <div className="no-print flex items-center justify-between">
        <Link href={`/app/ventes/${vente.id}`} className="text-sm text-mute hover:text-nuit">
          ← Retour à la vente
        </Link>
        <div className="flex gap-2">
          {client?.telephone ? (
            <a className="btn-ghost btn-sm" href={whatsappLink(client.telephone, resume)} target="_blank" rel="noreferrer">
              Envoyer sur WhatsApp
            </a>
          ) : null}
          <button className="btn-dark btn-sm" onClick={() => window.print()}>
            Imprimer
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-line bg-white p-6">
        <div className="border-b border-line pb-4 text-center">
          <h1 className="text-xl font-extrabold tracking-tight text-nuit">{boutique.nom}</h1>
          {boutique.adresse ? <p className="text-xs text-mute">{boutique.adresse}</p> : null}
          {boutique.telephone ? <p className="text-xs text-mute">Tél : {boutique.telephone}</p> : null}
        </div>

        <div className="flex justify-between py-4 text-sm">
          <div>
            <p className="text-xs text-mute">Reçu n°</p>
            <p className="font-semibold text-nuit">{p.numero_recu || "—"}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-mute">Date</p>
            <p className="font-semibold text-nuit">{dateFr(p.date_paiement)}</p>
          </div>
        </div>

        <p className="text-sm text-mute">Reçu de</p>
        <p className="mb-4 font-semibold text-nuit">{client?.nom || "Client de passage"}</p>

        <div className="rounded-xl bg-nuit-100/60 p-4 text-center">
          <p className="text-xs text-mute">Montant reçu ({MOYENS[p.moyen]})</p>
          <p className="text-2xl font-extrabold text-nuit">{fcfa(p.montant)}</p>
          {p.note ? <p className="text-xs text-mute">{p.note}</p> : null}
        </div>

        <div className="mt-4 space-y-1 border-t border-line pt-4 text-sm">
          {lignes.map((l: any) => (
            <div key={l.id} className="flex justify-between">
              <span className="text-ink">{l.designation}</span>
              <span>{fcfa(l.prix)}</span>
            </div>
          ))}
          <div className="flex justify-between border-t border-line pt-2 font-semibold text-nuit">
            <span>Total de l&apos;achat</span>
            <span>{fcfa(vente.total)}</span>
          </div>
          <div className="flex justify-between text-mute">
            <span>Déjà payé</span>
            <span>{fcfa(cumul)}</span>
          </div>
          <div className="flex justify-between font-bold text-nuit">
            <span>Reste à payer</span>
            <span>{reste > 0 ? fcfa(reste) : "Soldé"}</span>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-mute">Merci de votre confiance.</p>
      </div>
    </div>
  );
}
