"use client";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useBoutique } from "@/lib/boutique";
import { dateFr, fcfa, today, whatsappLink } from "@/lib/format";
import { Badge, Empty, Field, Loading, Modal, PageHeader } from "@/components/ui";

const ETAPES = [
  { id: "a_faire", label: "À faire", suivant: "en_fabrication", action: "Lancer la fabrication" },
  { id: "en_fabrication", label: "En fabrication", suivant: "pret", action: "Marquer prête" },
  { id: "pret", label: "Prêtes", suivant: "livre", action: "Marquer livrée" },
  { id: "livre", label: "Livrées", suivant: null, action: "" },
];

const VIDE = {
  client_id: "",
  description: "",
  artisan: "",
  titre: "",
  poids_estime: "",
  prix_convenu: "",
  acompte: "",
  date_livraison: "",
  statut: "a_faire",
};

export default function Commandes() {
  const { boutique, prix } = useBoutique();
  const titres = Object.keys(prix);
  const [commandes, setCommandes] = useState<any[] | null>(null);
  const [clients, setClients] = useState<any[]>([]);
  const [form, setForm] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const [voirLivrees, setVoirLivrees] = useState(false);

  const charger = useCallback(async () => {
    const [c, cl] = await Promise.all([
      supabase.from("commandes").select("*, clients(nom, telephone)").eq("boutique_id", boutique.id).order("date_livraison", { ascending: true, nullsFirst: false }),
      supabase.from("clients").select("id, nom, telephone").eq("boutique_id", boutique.id).order("nom"),
    ]);
    if (c.error) alert(c.error.message);
    setCommandes(c.data || []);
    setClients(cl.data || []);
  }, [boutique.id]);

  useEffect(() => {
    charger();
  }, [charger]);

  async function changerStatut(id: string, statut: string) {
    const { error } = await supabase.from("commandes").update({ statut }).eq("id", id);
    if (error) return alert(error.message);
    charger();
  }

  async function encaisserSolde(c: any) {
    if (!confirm(`Confirmer l'encaissement du solde (${fcfa(Number(c.prix_convenu) - Number(c.acompte))}) ?`)) return;
    const { error } = await supabase.from("commandes").update({ acompte: c.prix_convenu }).eq("id", c.id);
    if (error) return alert(error.message);
    charger();
  }

  async function enregistrer() {
    if (!form.description.trim()) return alert("Décris la commande (ex : bague sertie, taille 54).");
    setBusy(true);
    const payload = {
      boutique_id: boutique.id,
      client_id: form.client_id || null,
      description: form.description.trim(),
      artisan: form.artisan || null,
      titre: form.titre || null,
      poids_estime: form.poids_estime === "" ? null : Number(form.poids_estime),
      prix_convenu: Number(form.prix_convenu || 0),
      acompte: Number(form.acompte || 0),
      date_livraison: form.date_livraison || null,
      statut: form.statut,
    };
    const { error } = form.id
      ? await supabase.from("commandes").update(payload).eq("id", form.id)
      : await supabase.from("commandes").insert(payload);
    setBusy(false);
    if (error) return alert(error.message);
    setForm(null);
    charger();
  }

  async function supprimer() {
    if (!confirm("Supprimer cette commande ?")) return;
    const { error } = await supabase.from("commandes").delete().eq("id", form.id);
    if (error) return alert(error.message);
    setForm(null);
    charger();
  }

  if (!commandes) return <Loading />;
  const t = today();
  const etapes = voirLivrees ? ETAPES : ETAPES.filter((e) => e.id !== "livre");

  return (
    <div className="space-y-4">
      <PageHeader
        title="Commandes sur mesure"
        subtitle="De la demande du client jusqu'à la livraison."
        action={
          <button className="btn-primary" onClick={() => setForm({ ...VIDE, titre: titres[0] || "" })}>
            + Nouvelle
          </button>
        }
      />

      {commandes.filter((c) => c.statut !== "livre").length === 0 && !voirLivrees ? (
        <Empty>Aucune commande en cours. Enregistre la première avec le bouton ci-dessus.</Empty>
      ) : null}

      <div className="grid gap-4 md:grid-cols-3">
        {etapes.map((e) => {
          const liste = commandes.filter((c) => c.statut === e.id);
          if (liste.length === 0 && e.id !== "livre" && commandes.filter((c) => c.statut !== "livre").length === 0) return null;
          return (
            <section key={e.id} className="space-y-3">
              <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-mute">
                {e.label} <span className="rounded-full bg-nuit-100 px-2 py-0.5 text-xs text-nuit">{liste.length}</span>
              </h2>
              {liste.map((c) => {
                const reste = Math.max(0, Number(c.prix_convenu) - Number(c.acompte));
                const retard = c.statut !== "livre" && c.date_livraison && c.date_livraison < t;
                return (
                  <div key={c.id} className="card space-y-2">
                    <button className="w-full text-left" onClick={() => setForm({
                      ...VIDE, ...c,
                      client_id: c.client_id || "",
                      artisan: c.artisan || "",
                      titre: c.titre || "",
                      poids_estime: c.poids_estime ?? "",
                      prix_convenu: c.prix_convenu || "",
                      acompte: c.acompte || "",
                      date_livraison: c.date_livraison || "",
                    })}>
                      <p className="font-semibold text-nuit">{c.description}</p>
                      <p className="text-xs text-mute">
                        {c.clients?.nom || "Sans client"}
                        {c.artisan ? ` · Artisan : ${c.artisan}` : ""}
                      </p>
                    </button>
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      {c.date_livraison ? <Badge tone={retard ? "red" : "blue"}>Livraison {dateFr(c.date_livraison)}</Badge> : null}
                      {Number(c.prix_convenu) > 0 ? <Badge tone="gray">{fcfa(c.prix_convenu)}</Badge> : null}
                      {reste > 0 ? <Badge tone="orange">Reste {fcfa(reste)}</Badge> : Number(c.prix_convenu) > 0 ? <Badge tone="green">Payée</Badge> : null}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {e.suivant ? (
                        <button className="btn-dark btn-sm" onClick={() => changerStatut(c.id, e.suivant!)}>
                          {e.action}
                        </button>
                      ) : null}
                      {c.statut === "pret" && c.clients?.telephone ? (
                        <a
                          className="btn-ghost btn-sm"
                          target="_blank"
                          rel="noreferrer"
                          href={whatsappLink(c.clients.telephone, `Bonjour ${c.clients.nom}, ici ${boutique.nom}. Votre commande (${c.description}) est prête. Vous pouvez passer la récupérer.${reste > 0 ? ` Reste à régler : ${fcfa(reste)}.` : ""}`)}
                        >
                          Prévenir le client
                        </a>
                      ) : null}
                      {reste > 0 && c.statut !== "a_faire" ? (
                        <button className="btn-ghost btn-sm" onClick={() => encaisserSolde(c)}>
                          Encaisser le solde
                        </button>
                      ) : null}
                    </div>
                  </div>
                );
              })}
              {liste.length === 0 ? <p className="rounded-xl border border-dashed border-line p-4 text-center text-xs text-mute">Rien ici</p> : null}
            </section>
          );
        })}
      </div>

      <button className="text-sm font-semibold text-mute hover:text-nuit" onClick={() => setVoirLivrees(!voirLivrees)}>
        {voirLivrees ? "Masquer les commandes livrées" : `Voir les commandes livrées (${commandes.filter((c) => c.statut === "livre").length})`}
      </button>

      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? "Modifier la commande" : "Nouvelle commande"}>
        {form ? (
          <div className="space-y-3">
            <Field label="Client">
              <select className="input" value={form.client_id} onChange={(e) => setForm({ ...form, client_id: e.target.value })}>
                <option value="">Sans client</option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nom}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Description de la commande">
              <textarea className="input" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Ex : Bague gravée, taille 54, or 18k" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Artisan / atelier">
                <input className="input" value={form.artisan} onChange={(e) => setForm({ ...form, artisan: e.target.value })} />
              </Field>
              <Field label="Titre de l'or">
                <select className="input" value={form.titre} onChange={(e) => setForm({ ...form, titre: e.target.value })}>
                  <option value="">—</option>
                  {titres.map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </Field>
              <Field label="Poids estimé (g)">
                <input className="input" inputMode="decimal" value={form.poids_estime} onChange={(e) => setForm({ ...form, poids_estime: e.target.value.replace(",", ".") })} />
              </Field>
              <Field label="Date de livraison">
                <input className="input" type="date" value={form.date_livraison} onChange={(e) => setForm({ ...form, date_livraison: e.target.value })} />
              </Field>
              <Field label="Prix convenu (FCFA)">
                <input className="input" inputMode="numeric" value={form.prix_convenu} onChange={(e) => setForm({ ...form, prix_convenu: e.target.value })} />
              </Field>
              <Field label="Acompte reçu (FCFA)">
                <input className="input" inputMode="numeric" value={form.acompte} onChange={(e) => setForm({ ...form, acompte: e.target.value })} />
              </Field>
            </div>
            <Field label="Étape">
              <select className="input" value={form.statut} onChange={(e) => setForm({ ...form, statut: e.target.value })}>
                {ETAPES.map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.label}
                  </option>
                ))}
              </select>
            </Field>
            <div className="flex gap-2 pt-1">
              <button className="btn-primary flex-1" disabled={busy} onClick={enregistrer}>
                {busy ? "Enregistrement…" : "Enregistrer"}
              </button>
              {form.id ? (
                <button className="btn-danger" onClick={supprimer}>
                  Supprimer
                </button>
              ) : null}
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
