"use client";
import Link from "next/link";
import { accesAutorise, useBoutique } from "@/lib/boutique";
import { dateFr, whatsappLink } from "@/lib/format";
import { Badge, PageHeader } from "@/components/ui";

const PRIX = Number(process.env.NEXT_PUBLIC_PRIX_MENSUEL || 15000);
const MOYEN = process.env.NEXT_PUBLIC_MOYEN_PAIEMENT || "Wave ou Orange Money";
const SUPPORT = process.env.NEXT_PUBLIC_SUPPORT_WHATSAPP || "";

export default function Abonnement() {
  const { boutique, abonnement } = useBoutique();
  const acces = accesAutorise(abonnement);
  if (!boutique) return null;

  const message = `Bonjour, je souhaite activer mon abonnement Wurus pour la boutique « ${boutique.nom} ». Je viens d'envoyer le paiement.`;

  return (
    <div className="mx-auto max-w-lg space-y-5">
      <PageHeader title="Abonnement" subtitle="Garde Wurus actif pour continuer à gérer ta boutique." />

      <div className="card space-y-2">
        {acces ? (
          abonnement?.statut === "actif" ? (
            <Badge tone="green">Abonnement actif jusqu&apos;au {dateFr(abonnement.actif_jusqu_au)}</Badge>
          ) : (
            <Badge tone="orange">Essai gratuit jusqu&apos;au {dateFr(abonnement?.essai_fin)}</Badge>
          )
        ) : (
          <Badge tone="red">Abonnement expiré</Badge>
        )}
        {!acces ? (
          <p className="text-sm text-mute">
            Tes données sont conservées. Dès que ton paiement est confirmé, tu retrouves tout exactement comme avant.
          </p>
        ) : null}
      </div>

      <div className="card space-y-3">
        <h2 className="font-bold text-nuit">Comment payer</h2>
        <p className="text-3xl font-extrabold text-nuit">
          {new Intl.NumberFormat("fr-FR").format(PRIX).replace(/ | /g, " ")} <span className="text-base font-semibold text-mute">FCFA / mois</span>
        </p>
        <ol className="list-decimal space-y-1.5 pl-5 text-sm text-ink">
          <li>
            Envoie le montant par <strong>{MOYEN}</strong>.
          </li>
          <li>Préviens-nous sur WhatsApp avec le bouton ci-dessous.</li>
          <li>Ton abonnement est activé dès la confirmation du paiement.</li>
        </ol>
        {SUPPORT ? (
          <a className="btn-primary w-full" href={whatsappLink(SUPPORT, message)} target="_blank" rel="noreferrer">
            J&apos;ai payé : prévenir sur WhatsApp
          </a>
        ) : (
          <p className="rounded-xl bg-orange-50 px-3 py-2 text-sm text-orange-600">
            Le numéro de support n&apos;est pas encore configuré (variable NEXT_PUBLIC_SUPPORT_WHATSAPP).
          </p>
        )}
      </div>

      {acces ? (
        <Link href="/app" className="btn-ghost w-full">
          Retour à l&apos;accueil
        </Link>
      ) : null}
    </div>
  );
}
