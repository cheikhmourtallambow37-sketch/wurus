"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useBoutique } from "@/lib/boutique";
import { TITRES_DEFAUT } from "@/lib/format";
import { Field, Logo } from "@/components/ui";

export default function Onboarding() {
  const router = useRouter();
  const { reload } = useBoutique();
  const [nom, setNom] = useState("");
  const [tel, setTel] = useState("");
  const [adresse, setAdresse] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const { data: s } = await supabase.auth.getSession();
    const uid = s.session?.user.id;
    if (!uid) return router.replace("/connexion");
    const { data: b, error } = await supabase
      .from("boutiques")
      .insert({ owner_id: uid, nom, telephone: tel || null, adresse: adresse || null })
      .select()
      .single();
    if (error || !b) {
      setBusy(false);
      return setErr(error?.message || "Impossible de créer la boutique.");
    }
    await supabase.from("prix_or").insert(TITRES_DEFAUT.map((titre) => ({ boutique_id: b.id, titre, prix_gramme: 0 })));
    await reload();
    router.replace("/app/parametres");
  }

  return (
    <div className="mx-auto max-w-md pt-6">
      <div className="mb-6 flex justify-center">
        <Logo />
      </div>
      <form onSubmit={submit} className="card space-y-4">
        <div>
          <h1 className="h1">Bienvenue sur Wurus</h1>
          <p className="mt-1 text-sm text-mute">Dis-nous quelques mots sur ta bijouterie. Tu pourras tout modifier ensuite.</p>
        </div>
        <Field label="Nom de la bijouterie">
          <input className="input" required value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Ex : Bijouterie Teranga" />
        </Field>
        <Field label="Téléphone (affiché sur les reçus)">
          <input className="input" inputMode="tel" value={tel} onChange={(e) => setTel(e.target.value)} placeholder="77 000 00 00" />
        </Field>
        <Field label="Adresse">
          <input className="input" value={adresse} onChange={(e) => setAdresse(e.target.value)} placeholder="Marché, quartier, ville" />
        </Field>
        {err ? <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-600">{err}</p> : null}
        <button className="btn-primary w-full" disabled={busy}>
          {busy ? "Création…" : "Continuer"}
        </button>
      </form>
    </div>
  );
}
