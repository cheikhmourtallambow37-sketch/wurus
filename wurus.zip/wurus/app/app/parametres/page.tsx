"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { accesAutorise, useBoutique } from "@/lib/boutique";
import { dateFr } from "@/lib/format";
import { Badge, Field, PageHeader } from "@/components/ui";

export default function Parametres() {
  const router = useRouter();
  const { boutique, abonnement, prix, reload } = useBoutique();
  const [nom, setNom] = useState(boutique?.nom || "");
  const [tel, setTel] = useState(boutique?.telephone || "");
  const [adresse, setAdresse] = useState(boutique?.adresse || "");
  const [lignes, setLignes] = useState<{ titre: string; prix: string }[]>([]);
  const [nouveau, setNouveau] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    setLignes(Object.entries(prix).map(([titre, p]) => ({ titre, prix: p ? String(p) : "" })));
  }, [prix]);

  async function sauverBoutique() {
    const { error } = await supabase
      .from("boutiques")
      .update({ nom, telephone: tel || null, adresse: adresse || null })
      .eq("id", boutique.id);
    if (error) return alert(error.message);
    await reload();
    setMsg("Informations enregistrées.");
  }

  async function sauverPrix() {
    const rows = lignes
      .filter((l) => l.titre.trim())
      .map((l) => ({
        boutique_id: boutique.id,
        titre: l.titre.trim(),
        prix_gramme: Number(l.prix || 0),
        updated_at: new Date().toISOString(),
      }));
    const { error } = await supabase.from("prix_or").upsert(rows, { onConflict: "boutique_id,titre" });
    if (error) return alert(error.message);
    await reload();
    setMsg("Prix du gramme enregistrés. Les prix du stock sont recalculés.");
  }

  async function supprimerTitre(titre: string) {
    if (!confirm(`Supprimer le titre ${titre} ?`)) return;
    await supabase.from("prix_or").delete().eq("boutique_id", boutique.id).eq("titre", titre);
    await reload();
  }

  function ajouterTitre() {
    const t = nouveau.trim();
    if (!t || lignes.some((l) => l.titre === t)) return;
    setLignes([...lignes, { titre: t, prix: "" }]);
    setNouveau("");
  }

  async function deconnexion() {
    await supabase.auth.signOut();
    router.replace("/connexion");
  }

  if (!boutique) return null;
  const acces = accesAutorise(abonnement);

  return (
    <div className="space-y-5">
      <PageHeader title="Réglages" subtitle="Ta boutique, tes prix et ton abonnement." />
      {msg ? <p className="rounded-xl bg-green-50 px-3 py-2 text-sm text-green-700">{msg}</p> : null}

      <section className="card space-y-4">
        <h2 className="font-bold text-nuit">Prix du gramme par titre</h2>
        <p className="text-sm text-mute">
          Mets à jour ces prix quand le cours change : le prix de chaque pièce du stock se recalcule tout seul
          (poids × prix du gramme + façon).
        </p>
        <div className="space-y-2">
          {lignes.map((l, i) => (
            <div key={l.titre} className="flex items-center gap-2">
              <span className="w-16 rounded-lg bg-nuit-100 px-2 py-2 text-center text-sm font-semibold text-nuit">{l.titre}</span>
              <input
                className="input"
                inputMode="numeric"
                placeholder="Prix du gramme en FCFA"
                value={l.prix}
                onChange={(e) => setLignes(lignes.map((x, j) => (j === i ? { ...x, prix: e.target.value } : x)))}
              />
              <button className="btn-danger btn-sm" onClick={() => supprimerTitre(l.titre)} aria-label="Supprimer">
                ✕
              </button>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input className="input" placeholder="Nouveau titre (ex : 14k)" value={nouveau} onChange={(e) => setNouveau(e.target.value)} />
          <button className="btn-ghost" onClick={ajouterTitre}>
            Ajouter
          </button>
        </div>
        <button className="btn-primary" onClick={sauverPrix}>
          Enregistrer les prix
        </button>
      </section>

      <section className="card space-y-4">
        <h2 className="font-bold text-nuit">Ma boutique</h2>
        <Field label="Nom">
          <input className="input" value={nom} onChange={(e) => setNom(e.target.value)} />
        </Field>
        <Field label="Téléphone">
          <input className="input" inputMode="tel" value={tel} onChange={(e) => setTel(e.target.value)} />
        </Field>
        <Field label="Adresse">
          <input className="input" value={adresse} onChange={(e) => setAdresse(e.target.value)} />
        </Field>
        <button className="btn-dark" onClick={sauverBoutique}>
          Enregistrer
        </button>
      </section>

      <section className="card space-y-3">
        <h2 className="font-bold text-nuit">Abonnement</h2>
        <div className="flex flex-wrap items-center gap-2 text-sm">
          {abonnement?.statut === "actif" ? (
            <Badge tone={acces ? "green" : "red"}>Actif jusqu&apos;au {dateFr(abonnement.actif_jusqu_au)}</Badge>
          ) : (
            <Badge tone={acces ? "orange" : "red"}>
              {acces ? `Essai gratuit jusqu'au ${dateFr(abonnement?.essai_fin)}` : "Essai terminé"}
            </Badge>
          )}
          <Link href="/app/abonnement" className="font-semibold text-orange underline">
            Voir comment payer
          </Link>
        </div>
        <button className="btn-ghost" onClick={deconnexion}>
          Se déconnecter
        </button>
      </section>
    </div>
  );
}
