"use client";
import { ReactNode, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { BoutiqueContext, accesAutorise, joursRestantsEssai } from "@/lib/boutique";
import { Loading, Logo } from "@/components/ui";

const NAV = [
  { href: "/app", label: "Accueil", icon: "◧" },
  { href: "/app/stock", label: "Stock", icon: "◈" },
  { href: "/app/ventes", label: "Ventes", icon: "◉" },
  { href: "/app/commandes", label: "Commandes", icon: "✦" },
  { href: "/app/clients", label: "Clients", icon: "☺" },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [pret, setPret] = useState(false);
  const [boutique, setBoutique] = useState<any>(null);
  const [abonnement, setAbonnement] = useState<any>(null);
  const [prix, setPrix] = useState<Record<string, number>>({});

  const charger = useCallback(async () => {
    const { data: s } = await supabase.auth.getSession();
    if (!s.session) {
      router.replace("/connexion");
      return;
    }
    const { data: b } = await supabase.from("boutiques").select("*").maybeSingle();
    setBoutique(b);
    if (b) {
      const [{ data: ab }, { data: po }] = await Promise.all([
        supabase.from("abonnements").select("*").eq("boutique_id", b.id).maybeSingle(),
        supabase.from("prix_or").select("titre, prix_gramme").eq("boutique_id", b.id),
      ]);
      setAbonnement(ab);
      const m: Record<string, number> = {};
      (po || []).forEach((r: any) => (m[r.titre] = Number(r.prix_gramme)));
      setPrix(m);
    }
    setPret(true);
  }, [router]);

  useEffect(() => {
    charger();
  }, [charger]);

  const onboarding = pathname === "/app/onboarding";
  const acces = accesAutorise(abonnement);

  useEffect(() => {
    if (!pret) return;
    if (!boutique && !onboarding) router.replace("/app/onboarding");
    else if (boutique && onboarding) router.replace("/app");
    else if (boutique && !acces && pathname !== "/app/abonnement" && pathname !== "/app/parametres") {
      router.replace("/app/abonnement");
    }
  }, [pret, boutique, onboarding, acces, pathname, router]);

  if (!pret) return <Loading />;

  const jours = joursRestantsEssai(abonnement);

  return (
    <BoutiqueContext.Provider value={{ boutique, abonnement, prix, reload: charger }}>
      <div className="min-h-screen bg-white">
        {boutique ? (
          <header className="no-print sticky top-0 z-30 border-b border-line bg-white/95 backdrop-blur">
            <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
              <Link href="/app">
                <Logo />
              </Link>
              <div className="flex items-center gap-3">
                <span className="hidden text-sm text-mute sm:inline">{boutique.nom}</span>
                <Link href="/app/parametres" className="btn-ghost btn-sm">
                  Réglages
                </Link>
              </div>
            </div>
            <nav className="mx-auto hidden max-w-5xl gap-1 px-4 pb-2 sm:flex">
              {NAV.map((n) => {
                const actif = n.href === "/app" ? pathname === "/app" : pathname.startsWith(n.href);
                return (
                  <Link
                    key={n.href}
                    href={n.href}
                    className={`rounded-lg px-3 py-1.5 text-sm font-medium ${actif ? "bg-nuit text-white" : "text-mute hover:bg-nuit-100"}`}
                  >
                    {n.label}
                  </Link>
                );
              })}
            </nav>
          </header>
        ) : null}

        {boutique && abonnement?.statut === "essai" && acces && jours <= 7 ? (
          <div className="no-print bg-orange-50 px-4 py-2 text-center text-sm text-orange-600">
            Il te reste {jours} jour{jours > 1 ? "s" : ""} d&apos;essai gratuit.{" "}
            <Link href="/app/abonnement" className="font-semibold underline">
              Voir comment continuer
            </Link>
          </div>
        ) : null}

        <main className="mx-auto max-w-5xl px-4 pb-28 pt-5 sm:pb-10">{children}</main>

        {boutique && acces ? (
          <nav className="no-print fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-white sm:hidden">
            {NAV.map((n) => {
              const actif = n.href === "/app" ? pathname === "/app" : pathname.startsWith(n.href);
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${actif ? "text-orange" : "text-mute"}`}
                >
                  <span className="text-lg leading-none">{n.icon}</span>
                  {n.label}
                </Link>
              );
            })}
          </nav>
        ) : null}
      </div>
    </BoutiqueContext.Provider>
  );
}
