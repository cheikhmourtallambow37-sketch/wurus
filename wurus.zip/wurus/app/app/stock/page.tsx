"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";
import { prixProduit, useBoutique } from "@/lib/boutique";
import { CATEGORIES, fcfa, grammes } from "@/lib/format";
import { Badge, Empty, Field, Loading, Modal, PageHeader, Stat } from "@/components/ui";

const VIDE = {
  reference: "",
  nom: "",
  categorie: "Bague",
  titre: "",
  poids_g: "",
  pierres: "",
  facon: "",
  prix_fixe: "",
  statut: "en_stock",
  notes: "",
};

const STATUTS: Record<string, { label: string; tone: "green" | "orange" | "gray" }> = {
  en_stock: { label: "En stock", tone: "green" },
  reserve: { label: "Réservé", tone: "orange" },
  vendu: { label: "Vendu", tone: "gray" },
};

export default function Stock() {
  const { boutique, prix } = useBoutique();
  const titres = Object.keys(prix);
  const [items, setItems] = useState<any[] | null>(null);
  const [q, setQ] = useState("");
  const [filtre, setFiltre] = useState("en_stock");
  const [form, setForm] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);

  const charger = useCallback(async () => {
    const { data, error } = await supabase
      .from("produits")
      .select("*")
      .eq("boutique_id", boutique.id)
      .order("created_at", { ascending: false });
    if (error) alert(error.message);
    setItems(data || []);
  }, [boutique.id]);

  useEffect(() => {
    charger();
  }, [charger]);

  const enStock = useMemo(() => (items || []).filter((p) => p.statut === "en_stock"), [items]);
  const stats = useMemo(
    () => ({
      nb: enStock.length,
      poids: enStock.reduce((s, p) => s + Number(p.poids_g || 0), 0),
      valeur: enStock.reduce((s, p) => s + prixProduit(p, prix), 0),
    }),
    [enStock, prix]
  );

  const liste = useMemo(() => {
    const t = q.trim().toLowerCase();
    return (items || []).filter((p) => {
      if (filtre !== "tous" && p.statut !== filtre) return false;
      if (!t) return true;
      return [p.nom, p.reference, p.categorie, p.titre, p.pierres].some((v) => String(v || "").toLowerCase().includes(t));
    });
  }, [items, q, filtre]);

  function ouvrirNouveau() {
    const n = (items?.length || 0) + 1;
    setForm({ ...VIDE, titre: titres[0] || "", reference: "WU-" + String(n).padStart(4, "0") });
  }

  function ouvrirEdition(p: any) {
    setForm({
      ...p,
      poids_g: p.poids_g ?? "",
      facon: p.facon || "",
      prix_fixe: p.prix_fixe ?? "",
      pierres: p.pierres || "",
      notes: p.notes || "",
      reference: p.reference || "",
    });
  }

  async function enregistrer() {
    if (!form.nom.trim()) return alert("Donne un nom à la pièce.");
    setBusy(true);
    const payload = {
      boutique_id: boutique.id,
      reference: form.reference || null,
      nom: form.nom.trim(),
      categorie: form.categorie || null,
      titre: form.titre || null,
      poids_g: Number(form.poids_g || 0),
      pierres: form.pierres || null,
      facon: Number(form.facon || 0),
      prix_fixe: form.prix_fixe === "" ? null : Number(form.prix_fixe),
      statut: form.statut,
      notes: form.notes || null,
    };
    const { error } = form.id
      ? await supabase.from("produits").update(payload).eq("id", form.id)
      : await supabase.from("produits").insert(payload);
    setBusy(false);
    if (error) return alert(error.message);
    setForm(null);
    charger();
  }

  async function supprimer() {
    if (!confirm("Supprimer cette pièce du stock ?")) return;
    const { error } = await supabase.from("produits").delete().eq("id", form.id);
    if (error) return alert(error.message);
    setForm(null);
    charger();
  }

  if (!items) return <Loading />;

  const apercu = form ? prixProduit({ ...form, poids_g: Number(form.poids_g || 0), facon: Number(form.facon || 0) }, prix) : 0;
  const sansPrix = titres.length > 0 && titres.every((t) => !prix[t]);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Stock"
        subtitle="Tes pièces, leur poids et leur prix du jour."
        action={
          <button className="btn-primary" onClick={ouvrirNouveau}>
            + Ajouter
          </button>
        }
      />

      <div className="grid grid-cols-3 gap-3">
        <Stat label="Pièces en stock" value={stats.nb} />
        <Stat label="Poids total" value={grammes(stats.poids)} />
        <Stat label="Valeur du stock" value={fcfa(stats.valeur)} tone="orange" />
      </div>

      {sansPrix ? (
        <p className="rounded-xl bg-orange-50 px-3 py-2 text-sm text-orange-600">
          Pense à renseigner le prix du gramme dans Réglages : sans lui, les prix calculés restent à zéro.
        </p>
      ) : null}

      <div className="flex gap-2">
        <input className="input" placeholder="Rechercher (nom, référence, titre…)" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input max-w-[9rem]" value={filtre} onChange={(e) => setFiltre(e.target.value)}>
          <option value="en_stock">En stock</option>
          <option value="reserve">Réservés</option>
          <option value="vendu">Vendus</option>
          <option value="tous">Tous</option>
        </select>
      </div>

      {liste.length === 0 ? (
        <Empty>{items.length === 0 ? "Ton stock est vide. Ajoute ta première pièce avec le bouton ci-dessus." : "Aucune pièce ne correspond."}</Empty>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {liste.map((p) => (
            <button key={p.id} onClick={() => ouvrirEdition(p)} className="card text-left transition hover:border-orange">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-nuit">{p.nom}</p>
                  <p className="text-xs text-mute">
                    {p.reference || "Sans référence"} · {p.categorie || "—"}
                  </p>
                </div>
                <Badge tone={STATUTS[p.statut].tone}>{STATUTS[p.statut].label}</Badge>
              </div>
              <div className="mt-3 flex items-end justify-between">
                <p className="text-sm text-mute">
                  {p.titre || "—"} · {grammes(p.poids_g)}
                </p>
                <p className="font-bold text-nuit">{fcfa(prixProduit(p, prix))}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? "Modifier la pièce" : "Nouvelle pièce"}>
        {form ? (
          <div className="space-y-3">
            <Field label="Nom de la pièce">
              <input className="input" value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} placeholder="Ex : Bague solitaire" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Référence">
                <input className="input" value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} />
              </Field>
              <Field label="Catégorie">
                <select className="input" value={form.categorie} onChange={(e) => setForm({ ...form, categorie: e.target.value })}>
                  {CATEGORIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </Field>
              <Field label="Titre de l'or">
                <select className="input" value={form.titre} onChange={(e) => setForm({ ...form, titre: e.target.value })}>
                  <option value="">—</option>
                  {titres.map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
              </Field>
              <Field label="Poids (grammes)">
                <input className="input" inputMode="decimal" value={form.poids_g} onChange={(e) => setForm({ ...form, poids_g: e.target.value.replace(",", ".") })} />
              </Field>
              <Field label="Façon (FCFA)" hint="Main-d'œuvre ajoutée au prix.">
                <input className="input" inputMode="numeric" value={form.facon} onChange={(e) => setForm({ ...form, facon: e.target.value })} />
              </Field>
              <Field label="Prix fixe (optionnel)" hint="Remplace le prix calculé.">
                <input className="input" inputMode="numeric" value={form.prix_fixe} onChange={(e) => setForm({ ...form, prix_fixe: e.target.value })} />
              </Field>
            </div>
            <Field label="Pierres / détails">
              <input className="input" value={form.pierres} onChange={(e) => setForm({ ...form, pierres: e.target.value })} placeholder="Ex : 1 zircon, 0,3 ct" />
            </Field>
            <Field label="Statut">
              <select className="input" value={form.statut} onChange={(e) => setForm({ ...form, statut: e.target.value })}>
                <option value="en_stock">En stock</option>
                <option value="reserve">Réservé</option>
                <option value="vendu">Vendu</option>
              </select>
            </Field>
            <div className="rounded-xl bg-nuit-100 px-3 py-2 text-sm text-nuit">
              Prix affiché : <strong>{fcfa(apercu)}</strong>
            </div>
            <div className="flex gap-2 pt-1">
              <button className="btn-primary flex-1" disabled={busy} onClick={enregistrer}>
                {busy ? "Enregistrement…" : "Enregistrer"}
              </button>
              {form.id ? (
                <button className="btn-danger" onClick={supprimer}>
                  Supprimer
                </button>
              ) : null}
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
