"use client";
import { FormEvent, Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase, supabaseConfigured } from "@/lib/supabase";
import { Field, Logo } from "@/components/ui";

function Formulaire() {
  const router = useRouter();
  const params = useSearchParams();
  const [inscription, setInscription] = useState(params.get("mode") === "inscription");
  const [email, setEmail] = useState("");
  const [mdp, setMdp] = useState("");
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) router.replace("/app");
    });
  }, [router]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (!supabaseConfigured) {
      setMsg({ type: "err", text: "Supabase n'est pas configuré : ajoute les variables d'environnement (voir le guide)." });
      return;
    }
    setBusy(true);
    if (inscription) {
      const { data, error } = await supabase.auth.signUp({ email, password: mdp });
      setBusy(false);
      if (error) return setMsg({ type: "err", text: traduire(error.message) });
      if (data.session) return router.replace("/app");
      return setMsg({ type: "ok", text: "Compte créé. Vérifie ta boîte mail pour confirmer ton adresse, puis connecte-toi." });
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password: mdp });
    setBusy(false);
    if (error) return setMsg({ type: "err", text: traduire(error.message) });
    router.replace("/app");
  }

  return (
    <form onSubmit={submit} className="card space-y-4">
      <h1 className="h1">{inscription ? "Créer mon compte" : "Se connecter"}</h1>
      <Field label="Adresse e-mail">
        <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
      </Field>
      <Field label="Mot de passe" hint={inscription ? "6 caractères minimum." : undefined}>
        <input
          className="input"
          type="password"
          required
          minLength={6}
          value={mdp}
          onChange={(e) => setMdp(e.target.value)}
          autoComplete={inscription ? "new-password" : "current-password"}
        />
      </Field>
      {msg ? (
        <p className={`rounded-xl px-3 py-2 text-sm ${msg.type === "err" ? "bg-red-50 text-red-600" : "bg-green-50 text-green-700"}`}>
          {msg.text}
        </p>
      ) : null}
      <button className="btn-primary w-full" disabled={busy}>
        {busy ? "Patiente…" : inscription ? "Créer mon compte" : "Me connecter"}
      </button>
      <button type="button" className="w-full text-sm text-mute hover:text-nuit" onClick={() => { setInscription(!inscription); setMsg(null); }}>
        {inscription ? "J'ai déjà un compte" : "Pas encore de compte ? Créer le mien"}
      </button>
    </form>
  );
}

function traduire(m: string) {
  const s = m.toLowerCase();
  if (s.includes("invalid login")) return "E-mail ou mot de passe incorrect.";
  if (s.includes("already registered")) return "Cette adresse e-mail a déjà un compte.";
  if (s.includes("password")) return "Mot de passe trop court (6 caractères minimum).";
  if (s.includes("email not confirmed")) return "Confirme d'abord ton adresse e-mail (vérifie ta boîte mail).";
  return m;
}

export default function Connexion() {
  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-5 py-10">
      <Link href="/" className="mb-6 self-center">
        <Logo />
      </Link>
      <Suspense fallback={null}>
        <Formulaire />
      </Suspense>
    </div>
  );
}
