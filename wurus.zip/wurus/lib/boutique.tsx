"use client";
import { createContext, useContext } from "react";
import { today } from "./format";

export type BoutiqueCtx = {
  boutique: any;
  abonnement: any;
  prix: Record<string, number>;
  reload: () => Promise<void>;
};

export const BoutiqueContext = createContext<BoutiqueCtx>({
  boutique: null,
  abonnement: null,
  prix: {},
  reload: async () => {},
});

export const useBoutique = () => useContext(BoutiqueContext);

// Prix d'une pièce : prix fixe si renseigné, sinon poids × prix du gramme (selon le titre) + façon.
export function prixProduit(p: any, prix: Record<string, number>): number {
  if (p.prix_fixe !== null && p.prix_fixe !== undefined && p.prix_fixe !== "") return Number(p.prix_fixe);
  const g = prix[p.titre] || 0;
  return Math.round(Number(p.poids_g || 0) * g + Number(p.facon || 0));
}

export function accesAutorise(ab: any): boolean {
  if (!ab) return false;
  const t = today();
  if (ab.statut === "actif") return !ab.actif_jusqu_au || ab.actif_jusqu_au >= t;
  if (ab.statut === "essai") return ab.essai_fin >= t;
  return false;
}

export function joursRestantsEssai(ab: any): number {
  if (!ab || ab.statut !== "essai") return 0;
  const a = new Date(today() + "T00:00:00").getTime();
  const b = new Date(ab.essai_fin + "T00:00:00").getTime();
  return Math.max(0, Math.round((b - a) / 86400000));
}
