import { addMonths, today } from "./format";

export type Echeance = { n: number; date: string; montant: number };

// Échéancier : l'acompte est payé à la vente, le reste est réparti en versements mensuels égaux.
export function echeancier(vente: any): Echeance[] {
  const n = Number(vente.nb_versements || 0);
  if (!n) return [];
  const reste = Math.max(0, Number(vente.total) - Number(vente.acompte || 0));
  return Array.from({ length: n }, (_, i) => ({
    n: i + 1,
    date: addMonths(vente.date_vente, i + 1),
    montant: Math.round(reste / n),
  }));
}

export function etatCredit(vente: any, paye: number) {
  const total = Number(vente.total);
  const reste = Math.max(0, total - paye);
  const ech = echeancier(vente);
  const t = today();
  const dues = ech.filter((e) => e.date <= t);
  const attendu = Math.min(total, Number(vente.acompte || 0) + dues.reduce((s, e) => s + e.montant, 0));
  const retard = vente.statut === "en_cours" ? Math.max(0, attendu - paye) : 0;
  const prochaine = ech.find((e) => e.date > t) || null;
  return { total, paye, reste, retard, enRetard: retard > 0 && reste > 0, prochaine, echeances: ech };
}

// Indique pour chaque échéance si elle est couverte par les paiements déjà reçus.
export function echeancesCouvertes(vente: any, paye: number) {
  const ech = echeancier(vente);
  let cumul = Number(vente.acompte || 0);
  return ech.map((e) => {
    cumul += e.montant;
    return { ...e, payee: paye + 0.5 >= cumul };
  });
}
