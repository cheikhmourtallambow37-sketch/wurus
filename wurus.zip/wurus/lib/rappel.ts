import { dateFr, fcfa } from "./format";

export function messageRappel(opts: {
  client: string;
  boutique: string;
  dateVente: string;
  reste: number;
  retard: number;
  prochaine: { date: string; montant: number } | null;
}): string {
  const { client, boutique, dateVente, reste, retard, prochaine } = opts;
  if (retard > 0) {
    return (
      `Bonjour ${client}, ici ${boutique}. Petit rappel amical : un versement de ${fcfa(retard)} est en retard ` +
      `sur votre achat du ${dateFr(dateVente)}. Il vous reste ${fcfa(reste)} au total. ` +
      `Vous pouvez passer à la boutique ou payer par Wave / Orange Money. Merci beaucoup !`
    );
  }
  const suite = prochaine ? ` de ${fcfa(prochaine.montant)} prévu le ${dateFr(prochaine.date)}` : "";
  return (
    `Bonjour ${client}, ici ${boutique}. Petit rappel de votre prochain versement${suite}. ` +
    `Il vous reste ${fcfa(reste)} au total sur votre achat du ${dateFr(dateVente)}. Merci !`
  );
}
