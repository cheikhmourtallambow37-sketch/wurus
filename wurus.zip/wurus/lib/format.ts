export const TITRES_DEFAUT = ["18k", "21k", "22k", "24k"];

export const CATEGORIES = [
  "Bague",
  "Alliance",
  "Bracelet",
  "Collier",
  "Chaîne",
  "Pendentif",
  "Boucles d'oreilles",
  "Parure",
  "Autre",
];

export const MOYENS: Record<string, string> = {
  especes: "Espèces",
  wave: "Wave",
  orange_money: "Orange Money",
  virement: "Virement",
  autre: "Autre",
};

export function fcfa(n: number | string | null | undefined): string {
  const v = Math.round(Number(n || 0));
  return new Intl.NumberFormat("fr-FR").format(v).replace(/ | /g, " ") + " FCFA";
}

export function grammes(n: number | string | null | undefined): string {
  const v = Number(n || 0);
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(v).replace(/ | /g, " ") + " g";
}

export function ymd(d: Date): string {
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

export function today(): string {
  return ymd(new Date());
}

export function dateFr(s: string | null | undefined): string {
  if (!s) return "—";
  const [y, m, d] = s.slice(0, 10).split("-");
  return `${d}/${m}/${y}`;
}

export function addMonths(dateStr: string, k: number): string {
  const [y, m, d] = dateStr.slice(0, 10).split("-").map(Number);
  const target = new Date(y, m - 1 + k, 1);
  const max = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  target.setDate(Math.min(d, max));
  return ymd(target);
}

export function numeroRecu(): string {
  const d = new Date();
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const r = String(Math.floor(Math.random() * 9000) + 1000);
  return `R${yy}${mm}${dd}-${r}`;
}

export function whatsappLink(phone: string | null | undefined, message: string): string {
  let p = String(phone || "").replace(/\D/g, "");
  if (p.length === 9 && p.startsWith("7")) p = "221" + p; // numéro sénégalais sans indicatif
  const base = p ? `https://wa.me/${p}` : "https://wa.me/";
  return `${base}?text=${encodeURIComponent(message)}`;
}
