/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        nuit: { DEFAULT: "#0B1B3A", 700: "#16294f", 100: "#e6eaf2" },
        orange: { DEFAULT: "#F26B21", 600: "#d95a14", 50: "#fff3ea" },
        ink: "#1c2333",
        mute: "#6b7385",
        line: "#e7e9ef",
      },
      fontFamily: {
        sans: ["ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica", "Arial", "sans-serif"],
      },
    },
  },
  plugins: [],
};
