"use client";
import { ReactNode, useEffect } from "react";

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-nuit/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 sm:max-w-lg sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-nuit">{title}</h2>
          <button onClick={onClose} className="rounded-full px-2 py-1 text-mute hover:bg-nuit-100" aria-label="Fermer">
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {hint ? <p className="mt-1 text-xs text-mute">{hint}</p> : null}
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex items-start justify-between gap-3">
      <div>
        <h1 className="h1">{title}</h1>
        {subtitle ? <p className="mt-0.5 text-sm text-mute">{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-line p-8 text-center text-sm text-mute">{children}</div>;
}

export function Loading() {
  return <div className="p-8 text-center text-sm text-mute">Chargement…</div>;
}

export function Stat({ label, value, tone }: { label: string; value: ReactNode; tone?: "orange" | "red" | "nuit" }) {
  const color = tone === "red" ? "text-red-600" : tone === "orange" ? "text-orange" : "text-nuit";
  return (
    <div className="card">
      <p className="text-xs font-medium text-mute">{label}</p>
      <p className={`mt-1 text-lg font-bold ${color}`}>{value}</p>
    </div>
  );
}

export function Badge({ tone, children }: { tone: "green" | "orange" | "red" | "gray" | "blue"; children: ReactNode }) {
  const map: Record<string, string> = {
    green: "bg-green-50 text-green-700",
    orange: "bg-orange-50 text-orange-600",
    red: "bg-red-50 text-red-600",
    gray: "bg-gray-100 text-gray-600",
    blue: "bg-nuit-100 text-nuit",
  };
  return <span className={`badge ${map[tone]}`}>{children}</span>;
}

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2 font-extrabold tracking-tight">
      <span className="grid h-7 w-7 place-items-center rounded-lg bg-orange text-sm text-white">W</span>
      <span className={light ? "text-white" : "text-nuit"}>Wurus</span>
    </span>
  );
}
