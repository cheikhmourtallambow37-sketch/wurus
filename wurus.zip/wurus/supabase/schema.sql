-- =====================================================================
-- WURUS — schéma Supabase
-- À coller dans Supabase > SQL Editor > New query, puis "Run".
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- Boutiques (une par compte) ----------
create table if not exists boutiques (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  nom text not null,
  telephone text,
  adresse text,
  created_at timestamptz default now()
);

-- ---------- Abonnements (modifiable seulement par toi, depuis Supabase) ----------
create table if not exists abonnements (
  boutique_id uuid primary key references boutiques(id) on delete cascade,
  statut text not null default 'essai' check (statut in ('essai', 'actif', 'expire')),
  essai_fin date not null default (current_date + 30),
  actif_jusqu_au date,
  created_at timestamptz default now()
);

create or replace function creer_abonnement() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into abonnements (boutique_id) values (new.id);
  return new;
end $$;

drop trigger if exists trg_creer_abonnement on boutiques;
create trigger trg_creer_abonnement after insert on boutiques
  for each row execute function creer_abonnement();

-- ---------- Prix du gramme par titre d'or ----------
create table if not exists prix_or (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  titre text not null,
  prix_gramme numeric not null default 0,
  updated_at timestamptz default now(),
  unique (boutique_id, titre)
);

-- ---------- Stock ----------
create table if not exists produits (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  reference text,
  nom text not null,
  categorie text,
  titre text,
  poids_g numeric(10, 2) not null default 0,
  pierres text,
  facon numeric not null default 0,
  prix_fixe numeric,
  statut text not null default 'en_stock' check (statut in ('en_stock', 'reserve', 'vendu')),
  notes text,
  created_at timestamptz default now()
);
create index if not exists produits_boutique_idx on produits (boutique_id, statut);

-- ---------- Clients ----------
create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  nom text not null,
  telephone text,
  adresse text,
  notes text,
  created_at timestamptz default now()
);

-- ---------- Ventes ----------
create table if not exists ventes (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  client_id uuid references clients(id) on delete set null,
  date_vente date not null default current_date,
  total numeric not null,
  mode text not null check (mode in ('comptant', 'credit')),
  acompte numeric not null default 0,
  nb_versements int,
  echeance_finale date,
  statut text not null default 'en_cours' check (statut in ('en_cours', 'solde', 'annule')),
  notes text,
  created_at timestamptz default now()
);
create index if not exists ventes_boutique_idx on ventes (boutique_id, statut);

create table if not exists vente_lignes (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  vente_id uuid not null references ventes(id) on delete cascade,
  produit_id uuid references produits(id) on delete set null,
  designation text not null,
  prix numeric not null
);

-- ---------- Paiements (versements et reçus) ----------
create table if not exists paiements (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  vente_id uuid not null references ventes(id) on delete cascade,
  date_paiement date not null default current_date,
  montant numeric not null check (montant > 0),
  moyen text not null default 'especes' check (moyen in ('especes', 'wave', 'orange_money', 'virement', 'autre')),
  note text,
  numero_recu text,
  created_at timestamptz default now()
);
create index if not exists paiements_vente_idx on paiements (vente_id);

-- ---------- Commandes sur mesure ----------
create table if not exists commandes (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references boutiques(id) on delete cascade,
  client_id uuid references clients(id) on delete set null,
  description text not null,
  artisan text,
  titre text,
  poids_estime numeric,
  prix_convenu numeric not null default 0,
  acompte numeric not null default 0,
  date_livraison date,
  statut text not null default 'a_faire' check (statut in ('a_faire', 'en_fabrication', 'pret', 'livre')),
  created_at timestamptz default now()
);

-- =====================================================================
-- SÉCURITÉ (RLS) : chaque boutique ne voit et ne modifie que ses données
-- =====================================================================

create or replace function mes_boutiques() returns setof uuid
language sql stable security definer set search_path = public as $$
  select id from boutiques where owner_id = auth.uid()
$$;

alter table boutiques enable row level security;
alter table abonnements enable row level security;
alter table prix_or enable row level security;
alter table produits enable row level security;
alter table clients enable row level security;
alter table ventes enable row level security;
alter table vente_lignes enable row level security;
alter table paiements enable row level security;
alter table commandes enable row level security;

drop policy if exists "boutique_proprietaire" on boutiques;
create policy "boutique_proprietaire" on boutiques for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Abonnement : lecture seule pour le propriétaire (tu l'actives toi-même depuis Supabase)
drop policy if exists "abonnement_lecture" on abonnements;
create policy "abonnement_lecture" on abonnements for select
  using (boutique_id in (select mes_boutiques()));

do $$
declare t text;
begin
  foreach t in array array['prix_or', 'produits', 'clients', 'ventes', 'vente_lignes', 'paiements', 'commandes']
  loop
    execute format('drop policy if exists "donnees_boutique" on %I', t);
    execute format(
      'create policy "donnees_boutique" on %I for all using (boutique_id in (select mes_boutiques())) with check (boutique_id in (select mes_boutiques()))',
      t
    );
  end loop;
end $$;

-- =====================================================================
-- POUR ACTIVER UN ABONNEMENT (exemple, à lancer dans le SQL Editor) :
--   update abonnements
--      set statut = 'actif', actif_jusqu_au = current_date + 30
--    where boutique_id = (select id from boutiques where nom = 'Bijouterie X');
-- =====================================================================
