# Wurus — gestion de bijouterie

SaaS pour bijoutiers : stock au poids, ventes à crédit avec échéancier, reçus, rappels WhatsApp et commandes sur mesure.

**Stack** : Next.js 14 (React) · Tailwind · Supabase (base de données + comptes) · hébergement Vercel.

---

## Ce qui est inclus (v1)

- **Comptes** : inscription / connexion par e-mail, une boutique par compte, données isolées par boutique (sécurité RLS).
- **Stock au poids** : pièces avec titre d'or, poids, façon, pierres. Le prix se calcule tout seul : `poids × prix du gramme (selon le titre) + façon`. Un prix fixe est possible pour une pièce.
- **Réglages** : prix du gramme par titre (18k, 21k, 22k, 24k + titres personnalisés). Quand tu changes le prix, tout le stock se recalcule.
- **Clients** : fiches, total dû, appel et WhatsApp en un clic.
- **Ventes** : comptant ou à crédit (acompte + versements mensuels), échéancier automatique, détection des retards.
- **Paiements et reçus** : chaque versement génère un reçu imprimable, partageable sur WhatsApp.
- **Rappels** : message WhatsApp prérempli pour chaque client en retard.
- **Commandes sur mesure** : À faire → En fabrication → Prête → Livrée, avec artisan, acompte et date de livraison.
- **Abonnement** : 30 jours d'essai, puis activation manuelle par toi (voir plus bas).

---

## Mise en ligne, pas à pas (environ 20 minutes)

### 1. Supabase (base de données + comptes)

1. Crée un compte sur https://supabase.com puis **New project** (choisis une région proche, par ex. Paris ou Francfort).
2. Dans le projet : **SQL Editor → New query**, colle tout le contenu de `supabase/schema.sql`, clique **Run**.
3. **Project Settings → API** : note l'**URL du projet** et la clé **anon public**.
4. **Authentication → Providers → Email** : pour tester, désactive **Confirm email** (tu pourras le réactiver plus tard).

### 2. GitHub (le code)

1. Crée un dépôt vide sur https://github.com (par ex. `wurus`, en privé).
2. Sur ton PC, dans le dossier du projet :
   ```bash
   git init
   git add .
   git commit -m "Wurus v1"
   git branch -M main
   git remote add origin https://github.com/TON-COMPTE/wurus.git
   git push -u origin main
   ```

### 3. Vercel (l'hébergement)

1. Sur https://vercel.com, connecte-toi avec GitHub puis **Add New → Project** et choisis le dépôt `wurus`.
2. Avant de déployer, ouvre **Environment Variables** et ajoute :

   | Nom | Valeur |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | l'URL du projet Supabase |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | la clé anon public |
   | `NEXT_PUBLIC_SUPPORT_WHATSAPP` | ton numéro avec indicatif, sans + ni espaces (ex : `221770000000`) |
   | `NEXT_PUBLIC_PRIX_MENSUEL` | le prix de l'abonnement en FCFA (ex : `15000`) |
   | `NEXT_PUBLIC_MOYEN_PAIEMENT` | ex : `Wave ou Orange Money au 77 000 00 00` |

3. Clique **Deploy**. Tu obtiens une adresse `ton-projet.vercel.app`.
4. Retourne dans Supabase : **Authentication → URL Configuration** et mets cette adresse dans **Site URL**.

> Ne mets **jamais** de clé secrète (`service_role`) dans le code ni dans le chat. Seule la clé `anon` est utilisée ici.

### 4. Premier test

1. Ouvre ton site, crée un compte, renseigne la boutique.
2. Va dans **Réglages** et saisis le prix du gramme pour chaque titre.
3. Ajoute quelques pièces dans **Stock**, puis fais une vente à crédit et encaisse un versement.

---

## Activer l'abonnement d'un bijoutier

Quand un bijoutier t'a payé (Wave / Orange Money), dans Supabase → **SQL Editor** :

```sql
update abonnements
   set statut = 'actif', actif_jusqu_au = current_date + 30
 where boutique_id = (select id from boutiques where nom = 'Nom de sa boutique');
```

Pour prolonger d'un mois supplémentaire : `actif_jusqu_au = actif_jusqu_au + 30`.
Les bijoutiers ne peuvent pas modifier cette table eux-mêmes (sécurité RLS).

---

## Lancer en local

```bash
cp .env.example .env.local   # remplis les valeurs
npm install
npm run dev                  # http://localhost:3000
```

---

## Points d'attention avant de vendre

- **Plan Vercel gratuit** : le plan Hobby est prévu pour un usage non commercial. Pour encaisser des abonnements, vérifie les conditions de Vercel et prévois le plan payant ou un autre hébergeur.
- **Supabase gratuit** : un projet inactif pendant environ une semaine est mis en pause. Avec de vrais clients actifs ce n'est pas un problème, mais pense aux sauvegardes.
- **Blocage après expiration** : il est appliqué dans l'interface. Un utilisateur technique pourrait encore appeler l'API directement ; pour un blocage strict, ajoute le contrôle d'abonnement dans les règles RLS.
- **Création d'une vente** : les étapes (vente, lignes, stock, paiement) sont enregistrées l'une après l'autre. En cas de coupure réseau au mauvais moment, une vente peut être incomplète. À terme, à regrouper dans une fonction SQL unique.

## Idées pour la v2

Photos des pièces, rachat d'or ancien, statistiques mensuelles, paiement d'abonnement automatique (PayDunya, CinetPay ou PayTech), envoi automatique des rappels (API WhatsApp Business), plusieurs employés par boutique, installation sur l'écran d'accueil du téléphone (PWA).
